using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AttackState : State
{
    private AttackData _data;
    private FSMAgent _agent;

    private Coroutine _attackRoutine;
    private bool _isAttacking = false;
    private Transform _target;
    private Agent _targetAgent;
    private Vector3 _velocity;

    public void SetTarget(Transform target) => _target = target;

    public AttackState(AttackData data, FSMAgent agent)
    {
        _data = data;
        _agent = agent;
    }

    public override void Enter()
    {
        _velocity = Vector3.zero;
        _isAttacking = false;

        if (_target != null) _targetAgent = _target.GetComponentInParent<Agent>();

        Debug.Log($"[Attack] Enter. Target: {(_target != null ? _target.name : "null")}");
    }

    public override void Update()
    {
        if (_targetAgent != null && _targetAgent.IsDead)
        {
            Debug.Log("[Attack] Target eliminado, vuelvo a Patrol (pendiente: Gather).");
            _agent.FSM.ChangeState(_agent.Patrol);
            return;
        }

        if (_target == null)
        {
            Debug.Log("[Attack] Target nulo, vuelvo a Patrol.");
            _agent.FSM.ChangeState(_agent.Patrol);
            return;
        }

        float dist = Vector3.Distance(_target.position, _agent.transform.position);

        if (dist > _agent.PerceptionRadius)
        {
            Debug.Log("[Attack] Target fuera de rango de percepcion, vuelvo a Patrol (sin reiniciar TBA).");
            _agent.FSM.ChangeState(_agent.Patrol);
            return;
        }

        _velocity += SteeringUtils.CalculatePursuit(_agent.transform.position, _velocity, _data.ChaseSpeed, _data.ChaseForce, _target.position, _targetAgent.Velocity);
        _velocity.y = 0f;
        if (_velocity.sqrMagnitude > 0.0001f)
        {
            _agent.transform.position += _velocity * Time.deltaTime;
            _agent.transform.forward = _velocity;
            _agent.transform.position = Bounds.Instance.CalculateBoundPosition(_agent.transform.position);
        }

        if (!_isAttacking && dist <= _data.MeleeAttackRadius)
        {
            _targetAgent.TakeDamage(_data.AttackDamage * 2f);
            _isAttacking = true;
            _attackRoutine = _agent.StartCoroutine(AttackRoutine());
        }
        else if (!_isAttacking && dist <= _data.RangeAttackRadius)
        {
            _targetAgent.TakeDamage(_data.AttackDamage);
            _isAttacking = true;
            _attackRoutine = _agent.StartCoroutine(AttackRoutine());
        }
    }

    public override void Exit()
    {
        if (_attackRoutine != null)
        {
            _agent.StopCoroutine(_attackRoutine);
            _attackRoutine = null;
        }
        _isAttacking = false;
        _target = null;
        _targetAgent = null;
    }

    private IEnumerator AttackRoutine()
    {
        yield return new WaitForSeconds(_data.TimeBetweenAttacks);
        Debug.Log("[Attack] Ataque exitoso, reinicio TBA y vuelvo a Patrol.");
        _isAttacking = false;
        _agent.FSM.ChangeState(_agent.Patrol);
    }
}

[System.Serializable]
public class AttackData
{
    public float AttackDamage = 1f;
    public float MeleeAttackRadius = 3f;
    public float RangeAttackRadius = 6f;
    public float TimeBetweenAttacks = 5f;
    public float ChaseSpeed = 14f;
    public float ChaseForce = 14f;
}